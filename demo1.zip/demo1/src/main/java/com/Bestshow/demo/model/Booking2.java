package com.Bestshow.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="confirm")
public class Booking2 {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(length=100)
	private String  mloc;
	
	@Column(length=100)
	private String mtime;
	
	@Column(length=100)
	private String date;
	
	@Column(length=100)
	private String nameb;
	
	@Column(length=100)
	private String total_seats;
	
	@Column(length=100)
	private String seates;
	
	@Column(length = 50)
	private String movier;
	
	@Column(length = 50)
	private String amount;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMloc() {
		return mloc;
	}

	public void setMloc(String mloc) {
		this.mloc = mloc;
	}

	public String getMtime() {
		return mtime;
	}

	public void setMtime(String mtime) {
		this.mtime = mtime;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getNameb() {
		return nameb;
	}

	public void setNameb(String nameb) {
		this.nameb = nameb;
	}
	
	public String getTotal_seats() {
		return total_seats;
	}

	public void setTotal_seats(String total_seats) {
		this.total_seats = total_seats;
	}

	public String getSeates() {
		return seates;
	}

	public void setSeates(String seates) {
		this.seates = seates;
	}
	
	public String getMovier() {
		return movier;
	}

	public void setMovier(String movier) {
		this.movier = movier;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public Booking2(int id, String mloc, String mtime, String date, String nameb, String total_seats, String seates) {
		super();
		this.id = id;
		this.mloc = mloc;
		this.mtime = mtime;
		this.date = date;
		this.nameb = nameb;
		this.total_seats = total_seats;
		this.seates = seates;
	}

	public Booking2() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
