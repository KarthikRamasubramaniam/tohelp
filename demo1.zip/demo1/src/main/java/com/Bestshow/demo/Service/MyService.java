package com.Bestshow.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.Bestshow.demo.Repository.MyRepository;
import com.Bestshow.demo.model.MyModel;

@Service
public class MyService {
	
	@Autowired
	public MyRepository myrepo;
	
	  @Autowired
	private final JdbcTemplate jdbcTemplate;

    public MyService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
	
	public  MyModel tosave(MyModel model)
	{
		
		String password=
			(model.getName().substring(0,3))+(model.getPhno().substring(6,9));
		
		String username=(model.getPhno().substring(0,5))
				+(model.getName().substring(0,3));
		
		model.setUsername(username);
		model.setPassword(password);
		return myrepo.save(model);
	}
	
	public MyModel verifi(String username , String password)
	{
	
		return (MyModel) myrepo.findByUsernameAndPassword(username, password);
	}
	public List<MyModel> getAll() {
        return myrepo.findAll();
    }
	public boolean checkIfEmailExists(String emailid) {
	    // Check if any user with the given email ID exists in the database
	    return myrepo.existsByemailid(emailid);
	}

	public boolean checkIfPhoneNumberExists(String phno) {
	    // Check if any user with the given phone number exists in the database
	    return myrepo.existsByPhno(phno);
	}

	@SuppressWarnings("deprecation")
	public String getNameByUsername(String username,String password) {
		String sql = "SELECT name FROM register WHERE username = ? AND password = ?";
		try {
            return jdbcTemplate.queryForObject(sql, new Object[]{username, password}, String.class);
        } catch (EmptyResultDataAccessException e) {
            return null; // Handle the case when the user is not found
        }
		 
	}
}
