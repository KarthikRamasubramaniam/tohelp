package com.Bestshow.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Payment")
public class Payment {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(length=50)
	private String name;
	
	@Column(length=50)
	private String amount;
	
	@Column(length = 50)
	private String cardnumber;
	
	@Column(length = 50)
	private String expirydate;
	
	@Column(length=10)
	private String cvv;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCardnumber() {
		return cardnumber;
	}

	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}

	public String getExpirydate() {
		return expirydate;
	}

	public void setExpirydate(String expirydate) {
		this.expirydate = expirydate;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public Payment(int id, String name, String amount, String cardnumber, String expirydate, String cvv) {
		super();
		this.id = id;
		this.name = name;
		this.amount = amount;
		this.cardnumber = cardnumber;
		this.expirydate = expirydate;
		this.cvv = cvv;
	}

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
