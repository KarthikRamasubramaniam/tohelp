package com.Bestshow.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Bestshow.demo.model.Booking2;

public interface Book2repo  extends JpaRepository<Booking2, Integer>{
	 
	 
}
