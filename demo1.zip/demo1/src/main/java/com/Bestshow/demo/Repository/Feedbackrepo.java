package com.Bestshow.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Bestshow.demo.model.Feedback;

public interface Feedbackrepo extends JpaRepository<Feedback, Integer>{

}
