package com.Bestshow.demo.Service;

import com.Bestshow.demo.Repository.Pay;
import com.Bestshow.demo.model.Payment;

public class PayService {

public Pay pay;
	
	public Payment SavePay(Payment pay1)
	{
		return pay.save(pay1);
	}

}
