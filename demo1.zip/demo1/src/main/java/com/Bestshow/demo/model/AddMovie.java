package com.Bestshow.demo.model;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "Addmovie"  )
public class AddMovie {
		
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private int id;
		
		@Column(length = 50)
		private String mname;
		
		@Column(length = 50)
		private String  price;
		
		@Column(length = 50)
		private String mchars;
		
		@Column(length=50)
		private String year;
		
		@Column(length=100)
		private String imagePath;
		
		@Column(length=100)
		private String location;
		
		@Column(length=200)
		private String address;

			public String getImagePath() {
			return imagePath;
		}

		public void setImagePath(String imagePath) {
			this.imagePath = imagePath;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getMname() {
			return mname;
		}

		public void setMname(String mname) {
			this.mname = mname;
		}

		public String getPrice() {
			return price;
		}

		public void setPrice(String price) {
			this.price = price;
		}

		public String getMchars() {
			return mchars;
		}

		public void setMchars(String mchars) {
			this.mchars = mchars;
		}

		public String getYear() {
			return year;
		}

		public void setYear(String year) {
			this.year = year;
		}
		
		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}
		
		public AddMovie(int id, String mname, String price, String mchars, String year,String location, String address) {
			super();
			this.id = id;
			this.mname = mname;
			this.price = price;
			this.mchars = mchars;
			this.year = year;
			this.location = location;
			this.address = address;
		}

		public AddMovie() {
			super();
			// TODO Auto-generated constructor stub
		}

		@Override
		public String toString() {
			return "AddMovie [id=" + id + ", mname=" + mname + ", price=" + price + ", mchars=" + mchars + ", year="
					+ year + /*", image=" + image +*/ "]";
		}
		
		
				
		
}
