package com.Bestshow.demo.Repository;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Bestshow.demo.model.MyModel;

public interface MyRepository extends JpaRepository<MyModel, Integer> {
	
	//Optional<MyModel> findByUsernameAndPassword (String username,String password);

		MyModel findByUsernameAndPassword(String username, String password);
		
		boolean existsByemailid(String emailId);
	    
	    boolean existsByPhno(String phno);

		MyModel findByUsername(String username);
}
