package com.Bestshow.demo.controller;

import org.springframework.ui.Model;


import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.Bestshow.demo.Repository.AddTheater;
import com.Bestshow.demo.Repository.Book2repo;
import com.Bestshow.demo.Repository.MyRepository;
import com.Bestshow.demo.Service.Book2ser;
import com.Bestshow.demo.Service.FeedbackService;
import com.Bestshow.demo.Service.MyService;
import com.Bestshow.demo.Service.TheaterService;
import com.Bestshow.demo.model.AddMovie;

import com.Bestshow.demo.model.Booking2;
import com.Bestshow.demo.model.MyModel;
import com.Bestshow.demo.model.Feedback;
@Controller
public class MyController {
	
	@Autowired
	public MyService service;
	
	@Autowired
	public TheaterService ts;
	
	@Autowired
	public MyRepository myrepo;
	
	@Autowired
	private AddTheater addTheater;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private Book2ser b2s;
	
	@Autowired
	public Book2repo brepo;
	
	@Autowired
	public FeedbackService fs;
	
	@GetMapping("/")
	public String login(Model model)
	{
		model.addAttribute("loginRequest",new MyModel());
		return "Login";
	}
	
	@GetMapping("/signup")
	public String Reg(Model model )
	{
		model.addAttribute("registerRequest",new MyModel());
		return "Register";
	}
	
	@PostMapping("/signup")
	public String Postregiste(@ModelAttribute MyModel model,Model model3)
	{
		boolean emailExists = service.checkIfEmailExists(model.getEmailid());
	    boolean phoneExists = service.checkIfPhoneNumberExists(model.getPhno());

	    if (emailExists) {
	        model3.addAttribute("errorMessage", "Email ID already exists");
	        return "Register";
	    }

	    if (phoneExists) {
	        model3.addAttribute("errorMessage", "Phone number already exists");
	        return "Register";
	    }
		service.tosave(model);
		model3.addAttribute("successMessage", "Registered Successfully");
		return "redirect:/signup";
	}
	
	@PostMapping("/")
	public String loginVerification(@ModelAttribute MyModel model, HttpSession session) {
	    MyModel verification = service.verifi(model.getUsername(), model.getPassword());
	    if (verification != null) {
	        session.setAttribute("loggedInUser", verification.getUsername());
	        session.setAttribute("userpassword", verification.getPassword());
	        String name = service.getNameByUsername(model.getUsername(), model.getPassword());
		           session.setAttribute("name", name);
	        return "redirect:/home";
	    } else if (model.getUsername().equals("admin") && model.getPassword().equals("1234567")) {
	        session.setAttribute("loggedInUser", model.getUsername());
	        return "redirect:/admin";
	    } else {
	        return "/error";
	    }
	}

	@GetMapping("/home")
	public String home(Model model, HttpSession session) {
	    String loggedInUser = (String) session.getAttribute("loggedInUser");
	    String name = (String) session.getAttribute("name");    
	    model.addAttribute("loggedInUser", loggedInUser);
	    model.addAttribute("name", name);
	    // Add other necessary attributes to the model
	    return "Home";
	}

	@GetMapping("/polling")
	public String Polling(Model model )
	{
			List<AddMovie> movies = ts.getAllMovies();
			
			// Pass the list of movies to the view
			model.addAttribute("movies", movies);
	 
		return "Polling";
	}
	
	@GetMapping("/polling/image/{movieId}")
	@ResponseBody
	public ResponseEntity<Resource> getImage1(@PathVariable("movieId") int movieId) throws MalformedURLException {
	    AddMovie movie = addTheater.findById(movieId).orElse(null);
	    if (movie == null || movie.getImagePath() == null) {
	        return ResponseEntity.notFound().build();
	    }
	    String imagePath = "file:F:/6th sem web projects/demo/images/" + movie.getImagePath();
	    Resource resource = new UrlResource(imagePath);
	    if (!resource.exists()) {
	        return ResponseEntity.notFound().build();
	    }
	    return ResponseEntity.ok()
	            .contentType(MediaType.IMAGE_JPEG)
	            .body(resource);
	}
	
	@GetMapping("/booking")
	public String Booking(Model modelget , MyModel gname ,HttpSession session)
	{
		List<Booking2> b2data=b2s.getAll();
		
		  String name = (String) session.getAttribute("name");  
	    // Pass the list of movies to the view
		modelget.addAttribute("confirm",b2data);
		   modelget.addAttribute("name", name);
			return "Booking";
	}
	
	@GetMapping("/feedback")
	public String Feedback(Model model )
	{
		model.addAttribute("sendFeedback",new Feedback() );
			return "Sugestion";
	}
	
	@PostMapping("/feedback")
	public String pfeed(@ModelAttribute("sendFeedback") Feedback feed)
	{
		fs.toSave(feed);
		return "redirect:/feedback";
	}
	
	@GetMapping("/afeedback")
	public String AdminFeedback(Model model )
	{
			return "ViewFeedback";
	}
	
	@GetMapping("/admin")
	public String Admin()
	{
		return "Admin";
	}
	
	@GetMapping("/users")
	public ModelAndView User()
	{
		ModelAndView mav = new ModelAndView("AdminUsers");
		mav.addObject("register", myrepo.findAll());
		return mav;
	}

	@PostMapping("/deleteUser")
	public String deleteUser(@RequestParam("id") int id) {
	    // Retrieve the user from the database using the provided ID
	    MyModel user = myrepo.findById(id).orElse(null);
	    if (user != null) {
	        // Delete the user from the database
	        myrepo.delete(user);
	    }
	    // Redirect to the users page
	    return "redirect:/users";
	}
	
	@GetMapping("/book")
	public String AdminBooking(Model model5)
	{
		List<Booking2> bookmd=b2s.getAll();
		model5.addAttribute("confirm",bookmd);
		return "AdminBooking";
	}
	
	@PostMapping("/deletebook")
	public String deletebook(@RequestParam("id") int id) {
	    // Retrieve the user from the database using the provided ID
	    Booking2 book = brepo.findById(id).orElse(null);
	    if (book != null) {
	        // Delete the user from the database
	        brepo.delete(book);
	    }
	    return "redirect:/book";
	}
	
	@GetMapping("/at")
	public String AddTheater(Model model)
	{
		model.addAttribute("movieRequest",new AddMovie());
		return "AddTheater";
	}
	
	@PostMapping("/at")
	public String addMovie(@ModelAttribute("addMovie") AddMovie addMovie, Model model4,
	                       @RequestParam("image_path") MultipartFile imageFile) throws IOException {
	    if (!imageFile.isEmpty()) {
	        addMovie.setImagePath(imageFile.getOriginalFilename());
	        String saveFolderPath = "F:\\6th sem web projects\\demo\\images";
	        Path path = Paths.get(saveFolderPath + File.separator + imageFile.getOriginalFilename());
	        Files.copy(imageFile.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
	    }
	    boolean mnameExists = ts.checkIfmnameExists(addMovie.getMname());
	    boolean maddExists = ts.checkIfsddressExists(addMovie.getAddress());

	    if (mnameExists) {
	        model4.addAttribute("errorMessage", "Movie name already exists");
	        return "AddTheater";
	    }
	    if (maddExists) {
	        model4.addAttribute("errorMessage", "Movie adress already exists");
	        return "AddTheater";
	    }
	    addTheater.save(addMovie);
	    return "redirect:/vt";
	}

	@GetMapping("/vt")
	public String viewTheater(Model model) 
	{
		List<AddMovie> movies = ts.getAllMovies();	    
	    model.addAttribute("movies", movies);
	    return "ViewTheater";
	}
	
	@GetMapping("/vt/image/{movieId}")
	@ResponseBody
	public ResponseEntity<Resource> getImage(@PathVariable("movieId") int movieId) throws MalformedURLException {
	    AddMovie movie = addTheater.findById(movieId).orElse(null);
	    if (movie == null || movie.getImagePath() == null) {
	        return ResponseEntity.notFound().build();
	    }
	    String imagePath = "file:F:/6th sem web projects/demo/images/" + movie.getImagePath();
	    Resource resource = new UrlResource(imagePath);
	    if (!resource.exists()) {
	        return ResponseEntity.notFound().build();
	    }
	    return ResponseEntity.ok()
	            .contentType(MediaType.IMAGE_JPEG)
	            .body(resource);
	}

		@GetMapping("/book2")
		public String Book2(Model book)
		{
			//List<AddMovie> movies = ts.getAllMovies();
			book.addAttribute("confirmRequest",new Booking2());
		    // Pass the list of movies to the view
			//book.addAttribute("movies", movies);
			return "book2";
		}
		
		@PostMapping("/book2")
		public String saveBookingDetails(@ModelAttribute Booking2 booking,HttpSession session) {
			b2s.SaveBok(booking);
			 return "redirect:/home";
		}

		@GetMapping("/vt/delete/{movieId}")
		public String deleteMovie(@PathVariable("movieId") int movieId) {
		    addTheater.deleteById(movieId);
		    return "redirect:/vt";
		}
		
		@GetMapping("/vt/update/{movieId}")
		public String updateMovie(@PathVariable("movieId") int movieId, Model model) {
		    AddMovie movie = addTheater.findById(movieId).orElse(null);
		    if (movie == null) {
		        return "redirect:/vt";
		    }
		    model.addAttribute("movie", movie);
		    return "UpdateMovie";
		}

		@PostMapping("/vt/update/{movieId}")
		public String updateMovie(@PathVariable("movieId") int movieId, @ModelAttribute("movie") AddMovie updatedMovie) {
		    AddMovie movie = addTheater.findById(movieId).orElse(null);
		    if (movie != null) {
		        // Update the fields of the existing movie object with the new values
		        movie.setMname(updatedMovie.getMname());
		        movie.setPrice(updatedMovie.getPrice());
		        movie.setMchars(updatedMovie.getMchars());
		        movie.setYear(updatedMovie.getYear());
		        movie.setLocation(updatedMovie.getLocation());
		        movie.setAddress(updatedMovie.getLocation());
		        // Save the updated movie to the database
		        addTheater.save(movie);
		    }
		    return "redirect:/vt";
		}
		
		@GetMapping("/view")
		    public String show( Model model6,HttpSession session) {
			 String username = (String) session.getAttribute("loggedInUser");
			    String password = (String) session.getAttribute("userpassword");
			    List<Booking2> confirmations = b2s.getConfirmationsByUsernameAndPassword(username, password);
			    model6.addAttribute("confirmations", confirmations);
		        return "view";
		    }
		
}
	
