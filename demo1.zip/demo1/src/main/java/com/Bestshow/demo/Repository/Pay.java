package com.Bestshow.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Bestshow.demo.model.Payment;

public interface Pay extends JpaRepository<Payment, Integer>{

}
