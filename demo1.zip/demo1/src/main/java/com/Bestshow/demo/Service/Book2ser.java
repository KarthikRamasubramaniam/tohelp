package com.Bestshow.demo.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.Bestshow.demo.Repository.Book2repo;

import com.Bestshow.demo.model.Booking2;

@Service
public class Book2ser{
	@Autowired
	public Book2repo br;
	
	@Autowired
	private final JdbcTemplate jdbcTemplate;

	public Book2ser(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
	
	public Booking2 SaveBok(Booking2 br1)
	{
		return br.save(br1);
	}
	
	public List<Booking2> getAll() {
        return br.findAll();
    }

	 @SuppressWarnings("deprecation")
	public List<Booking2> getConfirmationsByUsernameAndPassword(String username, String password) {
	        String sql = "SELECT * FROM confirm WHERE nameb = (SELECT name FROM register WHERE username = ? AND password = ?)";
	        return jdbcTemplate.query(sql, new Object[]{username, password}, (rs, rowNum) -> {
	            Booking2 confirmation = new Booking2();
	            // Set confirmation properties based on the result set columns
	            confirmation.setMovier(rs.getString("movier"));
	            confirmation.setDate(rs.getString("date"));
	            confirmation.setMtime(rs.getString("mtime"));
	            confirmation.setNameb(rs.getString("nameb"));
	            // Set more properties as needed
	            return confirmation;
	        });        
		 }
}
