package com.Bestshow.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Bestshow.demo.model.AddMovie;

public interface AddTheater extends JpaRepository<AddMovie, Integer>{
	
	boolean existsByMname(String mname);
    
    boolean existsByAddress(String address);
  
}



