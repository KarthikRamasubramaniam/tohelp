package com.Bestshow.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Bestshow.demo.Repository.AddTheater;

import com.Bestshow.demo.model.AddMovie;


@Service
public class TheaterService {
	
	@Autowired
	AddTheater at;
		
	public  AddMovie tosave(AddMovie movie)
	{
			return at.save(movie);
	}
	
	public List<AddMovie> getAllMovies() {
        return at.findAll();
    }

	public boolean checkIfmnameExists(String mname) {
		// TODO Auto-generated method stub
		return at.existsByMname(mname);
	}

	public boolean checkIfsddressExists(String address) {
		// TODO Auto-generated method stub
		return at.existsByAddress(address);
	}
}
