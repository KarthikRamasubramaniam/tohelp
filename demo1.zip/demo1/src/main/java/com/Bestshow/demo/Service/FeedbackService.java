package com.Bestshow.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Bestshow.demo.Repository.Feedbackrepo;
import com.Bestshow.demo.model.Feedback;

@Service
public class FeedbackService {
		
		@Autowired
	  public Feedbackrepo fr;
		
		public Feedback toSave(Feedback f)
		{
			return fr.save(f);
		}
}
