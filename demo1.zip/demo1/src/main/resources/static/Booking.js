/**
 * 
 */
const container = document.querySelector('.container');
const seats = document.querySelectorAll('.row .seat:not(.occupied)');
const count = document.getElementById('count');
const total = document.getElementById('total');
const movieSelect = document.getElementById('movie');

populateUI();

function populateUI() {
  const selectedSeats = JSON.parse(localStorage.getItem('selectedSeats'));

  if (selectedSeats !== null && selectedSeats.length > 0) {
    seats.forEach((seat, index) => {
      if (selectedSeats.indexOf(index) > -1) {
        seat.classList.add('selected');
      }
    });
  }

  const selectedMovieIndex = localStorage.getItem('selectedMovieIndex');
  const movieSelect = document.getElementById('movie');
  const dateInput = document.getElementById('datepicker');

  if (selectedMovieIndex !== null && movieSelect !== null) {
    movieSelect.selectedIndex = selectedMovieIndex;
  }

  if (dateInput !== null) {
    dateInput.value = localStorage.getItem('selectedDate');
  }
}

// Seat click event
container.addEventListener('click', e => {
  if (
    e.target.classList.contains('seat') &&
    !e.target.classList.contains('occupied')
  ) {
    e.target.classList.toggle('selected');

    updateSelectedCount();
  }
});

function onLoaderFunc()
{
  $(".seatStructure *").prop("disabled", true);
  $(".displayerBoxes *").prop("disabled", true);
}

function takeData() {
  var username = $("#Username").val();
  var numSeats = $("#Numseats").val();
  var selectedTime = $("#selectt").val();
  var selectedDate = $("#datepicker").val();

  if (username.length === 0) {
    alert("Please enter your name");
    return;
  }

  if (numSeats.length === 0) {
    alert("Please enter the number of seats");
    return;
  }

  if (selectedTime.length === 0) {
    alert("Please select a time");
    return;
  }

  if (selectedDate.length === 0) {
    alert("Please select a date");
    return;
  }
  
  $(".inputForm *").prop("disabled", true);
  $(".seatStructure *").prop("disabled", false);
 
}

function updateTextArea() { 
    
  if ($("input:checked").length == ($("#Numseats").val()))
    {
      $(".seatStructure *").prop("disabled", true);
      
     var allNameVals = [];
     var allNumberVals = [];
     var allSeatsVals = [];
  
  	// Get the selected date
    var selectedDate = document.getElementById("datepicker").value;

    // Get the selected time
    var selectedTime = document.getElementById("selectt").value;
    
    var Mloc=document.getElementById("movieLoc").value;
    var Madd=document.getElementById("movieadd").value;
	
  		
     //Storing in Array
     allNameVals.push($("#Username").val());
     allNumberVals.push($("#Numseats").val());
     $('#seatsBlock :checked').each(function() {
       allSeatsVals.push($(this).val());
     });
    
     //Displaying 
     $('#nameDisplay').val(allNameVals);
     $('#NumberDisplay').val(allNumberVals);
     $('#seatsDisplay').val(allSeatsVals);
		
      var url = '/book2?name=' + allNameVals.join(',') +  '&number=' + allNumberVals.join(',') + '&seats=' + allSeatsVals.join(',')+'&mname='+movieName+'&cost='+movieCost
      +'&date='+selectedDate+'&time='+selectedTime+'&mloc='+Mloc+'&madd='+Madd;
    window.location.href = url;
   
    }
  else
    {
      alert("Please select " + ($("#Numseats").val()) + " seats")
    }
    
    
  }

function myFunction() {
  alert($("input:checked").length);
}

$(":checkbox").click(function() {
  if ($("input:checked").length == ($("#Numseats").val())) {
    $(":checkbox").prop('disabled', true);
    $(':checked').prop('disabled', false);
  }
  else
    {
      $(":checkbox").prop('disabled', false);
    }
});





