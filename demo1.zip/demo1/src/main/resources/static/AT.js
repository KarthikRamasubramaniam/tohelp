/**
 * 
 * 
 */
+ function($) {
  $('.palceholder').click(function() {
    $(this).siblings('input').focus();
  });

  $('.form-control').focus(function() {
    $(this).parent().addClass("focused");
  });

  $('.form-control').blur(function() {
    var $this = $(this);
    if ($this.val().length == 0)
      $(this).parent().removeClass("focused");
  });
  $('.form-control').blur();

  // validetion
  $.validator.setDefaults({
    errorElement: 'span',
    errorClass: 'validate-tooltip'
  });

  $("#formvalidate").validate({
    rules: {
      mname: {
        required: true,
        minlength: 3,
        maxlength:22
      },
       price:{
		   required: true,
		  minlength:3,
        maxlength:3
	  },
      mchars: {
        required: true,
        minlength: 3,
        maxlength:22
      },
      year:{
		  required: true,
		  minlength:4,
        maxlength:4
	  },
	  image:{
		  required: true,
	  },
	  location: {
        required: true,
        minlength: 5,
        maxlength:22
      },
       address:{
		   required: true,
		  minlength:10,
        maxlength:100
	  }, 
    },
    messages: {
      
      mname: {
        required: "Please enter Movie name.",
        minlength: "Name less than 3 characters.",
        maxlength: "Name more than 22 characters ."
      },
      
      price:
	  {
			required: "Please enter price of the movie.",
		  minlength:"price must be 3 digits",
        maxlength: "price must be 3 digits."
		  
	  },

      
      mchars: {
        required: "Enter movie characters.",
         minlength: "Name less than 3 characters.",
        maxlength: "Name more than 22 characters ."

      },
      
      year:{
		  required: "Please enter year of movie.",
		  minlength:"Year must be 4 digits",
        maxlength: "Year must be 4 digits."
	  },
	  
	  	  image:{
		  required: "Please upload image",
	  },
	  
	  location: {
        required: "Please enter the location.",
        minlength: "location less than 5 characters.",
        maxlength: "Name more than 22 characters ."
      },
      
      address:
	  {
			required: "Please enter address of the theater.",
		  minlength:"address must be 10 characters",
        maxlength: "address must be 50 characters."
		  
	  },
	  
    }
  });
}(jQuery);

function importData() {
  let input = document.createElement('input');
  input.type = 'file';
  input.onchange = _ => {
    // you can use this method to get file and perform respective operations
            let files =   Array.from(input.files);
            console.log(files);
        };
  input.click();
  
}