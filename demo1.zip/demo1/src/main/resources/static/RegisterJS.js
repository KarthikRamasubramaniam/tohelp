/**
 * 
 */
+ function($) {
  $('.palceholder').click(function() {
    $(this).siblings('input').focus();
  });

  $('.form-control').focus(function() {
    $(this).parent().addClass("focused");
  });

  $('.form-control').blur(function() {
    var $this = $(this);
    if ($this.val().length == 0)
      $(this).parent().removeClass("focused");
  });
  $('.form-control').blur();

  // validetion
  $.validator.setDefaults({
    errorElement: 'span',
    errorClass: 'validate-tooltip'
  });
  
  $("#formvalidate").validate({
    rules: {
      name: {
        required: true,
        minlength: 3,
        maxlength:22
      },
      emailid: {
        required: true,
      },
      phno:{
		  required: true,
        minlength: 10,
        maxlength:10
	  }
      
    },
    messages: {
      name: {
        required: "Please enter your username.",
        minlength: "Name less than 3 characters.",
        maxlength: "Name more than 22 characters ."
      },
      
      emailid: {
        required: "Enter your Email id.",
      },
      
      phno:{
		  required: "Please enter phone number.",
        minlength: "phone number must be 10 digits."
	  }
      
    }
  });

}(jQuery);

