/**
 * 
 */
/*+ function($) {
  $('.palceholder').click(function() {
    $(this).siblings('input').focus();
  });

  $('.form-control').focus(function() {
    $(this).parent().addClass("focused");
  });

  $('.form-control').blur(function() {
    var $this = $(this);
    if ($this.val().length == 0)
      $(this).parent().removeClass("focused");
  });
  $('.form-control').blur();

  // validetion
  $.validator.setDefaults({
    errorElement: 'span',
    errorClass: 'validate-tooltip'
  });

  $("#formvalidate").validate({
    rules: {
      username: {
        required: true,
        minlength: 5
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    messages: {
      username: {
        required: "Please enter your username.",
        minlength: "Please provide valid username."
      },
      password: {
        required: "Enter your password to Login.",
        minlength: "Incorrect login or password."
      }
    }
  });
  
  

    

}(jQuery);

 */

 $(document).ready(function($) {
  $('.palceholder').click(function() {
    $(this).siblings('input').focus();
  });

  $('.form-control').focus(function() {
    $(this).parent().addClass("focused");
  });

  $('.form-control').blur(function() {
    var $this = $(this);
    if ($this.val().length == 0)
      $(this).parent().removeClass("focused");
  });
  $('.form-control').blur();

  // validation
  $.validator.setDefaults({
    errorElement: 'span',
    errorClass: 'validate-tooltip'
  });

  $("#formvalidate").validate({
    rules: {
      username: {
        required: true,
        minlength: 5
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    messages: {
      username: {
        required: "Please enter your username.",
        minlength: "Please provide a valid username."
      },
      password: {
        required: "Enter your password to login.",
        minlength: "Incorrect login or password."
      }
    }
  });

  // Check if user is logged in
  var isLoggedIn = sessionStorage.getItem('isLoggedIn');
  if (isLoggedIn) {
    // Disable browser forward button
    history.pushState(null, null, location.href);
    window.onpopstate = function() {
      history.go(1);
    };
  } else {
    // Clear stored flag when user is not logged in
    sessionStorage.removeItem('isLoggedIn');
  }

  // Function to handle login
  function handleLogin() {
    // Perform your login logic here
    var username = document.getElementById('userName').value;
    var password = document.getElementById('userPassword').value;

    // Example: Check if username and password are valid
    if (username === 'admin' && password === '1234567') {
      // Set flag in sessionStorage
      sessionStorage.setItem('isLoggedIn', true);

      // Redirect to the home page or desired location
      window.location.href = '/home';
    } else {
      // Display an error message or handle unsuccessful login
    }
    
    // Disable browser forward button
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
      history.go(1);
    };
  }
});
